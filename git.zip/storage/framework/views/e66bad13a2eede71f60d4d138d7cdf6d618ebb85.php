
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<?php $__env->startSection('scripts'); ?>
<?php echo $__env->yieldSection(); ?>
</body>
</head><?php /**PATH E:\MXC\Bigcommerce\warm-sands-18526\resources\views/layout/footer.blade.php ENDPATH**/ ?>