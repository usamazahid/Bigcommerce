

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
<link rel="stylesheet" href="https://cdn.datatables.net/select/1.3.3/css/select.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/dataTables.checkboxes.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<div class="container-fluid">
<h2>Orders</h2>
<hr>
<table id="table_orders" class="display">
    <thead>
        <tr>
            <th>Column 1</th>
            <th>Column 2</th>
            <th>Column 2</th>
        </tr>
    </thead>
    <tbody>

	<?php $__currentLoopData = $order_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td></td>
		<td><input type="text" name="order_id" id="order_id" value="<?php echo e($order['order_id']); ?>" readonly></td>
		<td><input type="text" name="date_created" id="date_created" value="<?php echo e($order['shipping_address']->first_name); ?>" readonly></td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

	<pre>
		<?php echo e(print_r($order_data)); ?>


	</pre>
    </tbody>
</table>

<input type="submit" class="btn btn-primary" value="POST" id="btn_submit">

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
<script src="https://cdn.datatables.net/select/1.3.3/js/dataTables.select.min.js"></script>
<script type="text/javascript" charset="utf8" src="<?php echo e(asset('assets/js/dataTables.checkboxes.min.js')); ?>"></script>
<script>
$(document).ready( function () {

   var table = $('#table_orders').DataTable({
        searching: false,
        columnDefs: [{
        	'width':"1%",
            'checkboxes': {
            'selectRow': true
            },
            targets:   0
        }],
         select: {
            style:    'multi',
            selector: 'td:first-child'
        }
    });

   $('#btn_submit').on('click', function(){
	var data = table.rows({selected:  true}).nodes().to$();
	var bookingData = [];
	var error = false;


	$.each(data, function(index, rowId){

	let obj = Object.fromEntries(new URLSearchParams($(rowId).find('input, select').serialize()));

	// var cityIndex = citiesList.findIndex(x => x.CityName.trim() === obj.consignee_city.toUpperCase().trim());

	// if( cityIndex < 0){
	//   alert("Invalid City Name: " + obj.consignee_city);
	//       error = true;
	//       return false;
	// }else if(obj.weight  == "" || obj.weight <= 0){
	//   alert("Weight Cannot be Empty or 0");
	//       error = true;
	//       return false;
	//  }
	 
	bookingData.push(obj);

	});

	console.log(bookingData);
	});

} );

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\warm-sands-18526\resources\views/orders.blade.php ENDPATH**/ ?>