
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<?php $__env->startSection('scripts'); ?>
<?php echo $__env->yieldSection(); ?>
</body>
</head><?php /**PATH /home4/nr6grat3/bc.mxclogistics.com/resources/views/layout/footer.blade.php ENDPATH**/ ?>