<select  name="consignee_city" id="consignee_city" class="form-control input-lg">
    <option value="<?php echo e(strtoupper($cname)); ?>" selected><?php echo e(strtoupper($cname)); ?></option>
    <?php $__currentLoopData = $CityList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($selected=""); ?>

        <?php if($city->CityName == strtoupper($cname)): ?>
            <?php $selected = 'selected' ?>
        <?php endif; ?>

        <option value="<?php echo e($city->CityName); ?>" <?php echo e($selected); ?>><?php echo e($city->CityName); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</select>
<?php /**PATH /home4/nr6grat3/bc.mxclogistics.com/resources/views/components/city-list.blade.php ENDPATH**/ ?>