<select  name="service_type" id="service_type" class="form-control input-lg">
        <?php if($sname == 'Cash on Delivery'): ?>
        <option value="1" selected>COD</option>
        <?php else: ?>
        <option value="5" selected>Zero COD</option>
        <?php endif; ?>
    
</select>
<?php /**PATH /home4/nr6grat3/bc.mxclogistics.com/resources/views/components/service-list.blade.php ENDPATH**/ ?>