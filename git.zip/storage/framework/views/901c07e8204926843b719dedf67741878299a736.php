

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
<link rel="stylesheet" href="https://cdn.datatables.net/select/1.3.3/css/select.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/dataTables.checkboxes.css')); ?>">
<style type="text/css">
	.form-control{
		width: auto !important;
	}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<div class="container-fluid">
<h2>Orders</h2>
<hr>
<table id="table_orders" class="display">
    <thead>
        <tr>
             <th></th>
            <th>Order#</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Address</th>
            <th>City</th>
            <th>Reference</th>
            <th>Description</th>
            <th>Amount</th>
            <th>Items</th>
            <th>Weight</th>
            <th>Service</th>
            <th>Remarks</th>
            <th>Order ID</th>
            <th>Options</th>
        </tr>
    </thead>
    <tbody>

	<?php $__currentLoopData = $order_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td></td>
		<td><input type="text" name="order_number" id="order_number" class="form-control" value="<?php echo e($order['order_id']); ?>" readonly></td>
		<td><input type="text" name="consignee_name" id="consignee_name" class="form-control" value="<?php echo e($order['shipping_address']->first_name . ' ' .$order['shipping_address']->last_name); ?>"></td>
		<td><input type="text" name="consignee_email" id="consignee_email" class="form-control" value="<?php echo e($order['shipping_address']->email); ?>"></td>
		<td><input type="text" name="consignee_cell" id="consignee_cell" class="form-control" value="<?php echo e($order['shipping_address']->phone); ?>"></td>
		<td><input type="text" name="consignee_address" id="consignee_address" class="form-control" value="<?php echo e($order['shipping_address']->street_1 . ' ' . $order['shipping_address']->street_2); ?>"></td>
		<td><?php if (isset($component)) { $__componentOriginal7f632daab2a0d5838657f68609eec667052f864d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CityList::class, ['cname' => ''.e($order['shipping_address']->city).'']); ?>
<?php $component->withName('CityList'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f632daab2a0d5838657f68609eec667052f864d)): ?>
<?php $component = $__componentOriginal7f632daab2a0d5838657f68609eec667052f864d; ?>
<?php unset($__componentOriginal7f632daab2a0d5838657f68609eec667052f864d); ?>
<?php endif; ?></td>
		<td><input type="text" name="consignee_reference" id="consignee_reference" class="form-control" value="<?php echo e($order['order_id']); ?>"></td>
		<td><input type="text" name="consignment_description" id="consignment_description" class="form-control" value="<?php echo e($order['product_description']); ?>"></td>
		<td><input type="text" name="amount" id="amount" class="form-control" value="<?php echo e($order['total_inc_tax']); ?>"></td>
		<td><input type="text" name="pieces" id="pieces" class="form-control" value="<?php echo e($order['items']); ?>"></td>
		<td><input type="text" name="weight" id="weight" class="form-control" value="<?php echo e($order['product_weight']); ?>"></td>
		<td><?php if (isset($component)) { $__componentOriginal80a4cba2277dd73a86711d447e1756bba9da5c47 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ServiceList::class, ['sname' => ''.e($order['payment_method']).'']); ?>
<?php $component->withName('ServiceList'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal80a4cba2277dd73a86711d447e1756bba9da5c47)): ?>
<?php $component = $__componentOriginal80a4cba2277dd73a86711d447e1756bba9da5c47; ?>
<?php unset($__componentOriginal80a4cba2277dd73a86711d447e1756bba9da5c47); ?>
<?php endif; ?></td>
		<td><input type="text" name="consignment_remarks" id="consignment_remarks" class="form-control" value=""></td>
		<td><input type="text" name="order_id" id="order_id" class="form-control" value="<?php echo e($order['order_id']); ?>"></td>
		<td><input type="submit" name="btn_partial_shipment"  class="btn btn-info btn_partial_shipment" class="form-control" value="Partial Shipment" data-order-id="<?php echo e($order['order_id']); ?>"></td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

<!-- 	<pre>
		<?php echo e(print_r($order_data)); ?>


	</pre> -->
    </tbody>
</table>

<input type="submit" class="btn btn-primary" value="POST" id="btn_submit">
<input type="submit" class="btn btn-success" value="PRINT" id="btn_print" hidden>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
<script src="https://cdn.datatables.net/select/1.3.3/js/dataTables.select.min.js"></script>
<script type="text/javascript" charset="utf8" src="<?php echo e(asset('assets/js/dataTables.checkboxes.min.js')); ?>"></script>
<script>
$(document).ready( function () {
	
	var citiesList = [];

	$.ajax({
		url: "/citylist",
		method: "get",
		dataType: 'json',
		success: function(data){
		    
		citiesList = data;
		console.log(citiesList);
		console.log(citiesList.findIndex(x => x.CityName ==="ISLAMABAD"));
		},
		error: function(data){
		    console.log(data);
		}
	});

   	
   	var table = $('#table_orders').DataTable({
        searching: false,
        scrollX: true,
        columnDefs: [{
        	'width':"1%",
            'checkboxes': {
            'selectRow': true
            },
            targets:   0
        }],
         select: {
            style:    'multi',
            selector: 'td:first-child'
        }
    });

   $('#btn_submit').on('click', function(){
	var data = table.rows({selected:  true}).nodes().to$();
	var bookingData = [];
	var error = false;


	$.each(data, function(index, rowId){

	let obj = Object.fromEntries(new URLSearchParams($(rowId).find('input, select').serialize()));

	var cityIndex = citiesList.findIndex(x => x.CityName.trim() === obj.consignee_city.toUpperCase().trim());

	if( cityIndex < 0){
	  alert("Invalid City Name: " + obj.consignee_city);
	      error = true;
	      return false;
	}else if(obj.weight  == "" || obj.weight <= 0){
	  alert("Weight Cannot be Empty or 0");
	      error = true;
	      return false;
	 }
	 
	bookingData.push(obj);

	});

	if(!error && bookingData.length >= 1){
	
	$(this).prop('disabled', true);
	

		$.ajax({
			url: "fulfilment",
			method: "post",
			data: {"bulk":"<?php echo e($mxc_id); ?>", "data" : bookingData},
			success: function(data){
			console.log(data);
			$('#btn_print').removeAttr('hidden');
			},
			error: function(data){
			console.log(data);
			}
		});
	}  

	console.log(bookingData);
	});

   $('#btn_print').on('click', function() {

   		window.location.href = "/slip?uid=<?php echo e($mxc_id); ?>&context=<?php echo e($store_hash); ?>";
   });


   	const divs = document.querySelectorAll('.btn_partial_shipment');
	divs.forEach(el => el.addEventListener('click', event => {
	$(this).prop('disabled', true);
	  window.location.href = "/PartialShipment?order_id="+event.target.getAttribute('data-order-id')+"&action=partial_shipment&context=<?php echo e($store_hash); ?>";
	}));

} );

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MXC\Bigcommerce\warm-sands-18526\resources\views/orders.blade.php ENDPATH**/ ?>