<select  name="service_type" id="service_type" class="form-control input-lg">
        <?php if($sname == ''): ?>
        <option value="1" selected>COD</option>
        <?php else: ?>
        <option value="5" selected>Zero COD</option>
        <?php endif; ?>
    
</select>
<?php /**PATH E:\MXC\Bigcommerce\warm-sands-18526\resources\views/components/service-list.blade.php ENDPATH**/ ?>