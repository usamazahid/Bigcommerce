<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- PAGE TITLE HERE -->
    <title></title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <?php $__env->startSection('style'); ?>
    <?php echo $__env->yieldSection(); ?>
</head>

<body>
<?php /**PATH E:\MXC\Bigcommerce\warm-sands-18526\resources\views/layout/header.blade.php ENDPATH**/ ?>