<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 
<!--**********************************
    Content body start
***********************************-->
<?php echo $__env->yieldContent('container'); ?>
<!--**********************************
    Content body end
***********************************-->


<!--**********************************
Footer start
***********************************-->
<?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--**********************************
Footer end
***********************************-->
       <?php /**PATH /home4/nr6grat3/bc.mxclogistics.com/resources/views/layout/layout.blade.php ENDPATH**/ ?>